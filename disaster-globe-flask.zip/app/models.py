import json
from pathlib import Path
from flask import current_app

def load_incidents():
    path = Path(current_app.config['INCIDENTS_FILE'])
    if not path.exists():
        return {"type": "FeatureCollection", "features": []}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
