from flask import Blueprint, jsonify, current_app, request
from .models import load_incidents
import time

bp = Blueprint("api", __name__)

@bp.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "timestamp": int(time.time())})

@bp.route("/incidents", methods=["GET"])
def incidents():
    data = load_incidents()
    features = data.get("features", [])
    severity_min = request.args.get("severity_min", type=float)
    severity_max = request.args.get("severity_max", type=float)
    if severity_min is not None or severity_max is not None:
        out = []
        for f in features:
            sev = f.get("properties", {}).get("severity", 0)
            if severity_min is not None and sev < severity_min:
                continue
            if severity_max is not None and sev > severity_max:
                continue
            out.append(f)
        return jsonify({"type":"FeatureCollection", "features": out})
    return jsonify(data)
