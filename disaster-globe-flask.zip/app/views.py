from flask import Blueprint, send_from_directory, current_app

bp = Blueprint("views", __name__)

@bp.route("/", methods=["GET"])
def index():
    return send_from_directory(current_app.static_folder, "index.html")
