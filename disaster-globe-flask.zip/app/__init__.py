from flask import Flask
from .config import Config

def create_app(config_class=Config):
    app = Flask(__name__, static_folder="static", template_folder="static")
    app.config.from_object(config_class)

    from .api import bp as api_bp
    app.register_blueprint(api_bp, url_prefix="/api")

    from .views import bp as views_bp
    app.register_blueprint(views_bp)

    return app
