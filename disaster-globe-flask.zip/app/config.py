import os

class Config:
    ENV = os.environ.get("FLASK_ENV", "production")
    DEBUG = os.environ.get("FLASK_DEBUG", "0") == "1"
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-in-prod")
    INCIDENTS_FILE = os.environ.get("INCIDENTS_FILE", "app/static/assets/data/incidents.geojson")
