// main.js - Three.js + three-globe bootstrap
(async function(){
  const container = document.getElementById('canvas-container');
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(40, innerWidth/innerHeight, 0.1, 1000);
  camera.position.z = 220;

  const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
  renderer.setSize(innerWidth, innerHeight);
  renderer.domElement.style.zIndex = 10;
  renderer.domElement.style.position = 'absolute';
  container.appendChild(renderer.domElement);

  window.addEventListener('resize', () => {
    renderer.setSize(innerWidth, innerHeight);
    camera.aspect = innerWidth/innerHeight;
    camera.updateProjectionMatrix();
  });

  scene.add(new THREE.AmbientLight(0xffffff, 0.7));
  const dir = new THREE.DirectionalLight(0xffffff,0.6);
  dir.position.set(5,3,5);
  scene.add(dir);

  const Globe = new ThreeGlobe({ animateIn: true });
  const earthImg = 'assets/textures/earth-dark.jpg';
  Globe
    .globeImageUrl(earthImg)
    .bumpImageUrl('https://unpkg.com/three-globe/example/img/earth-topology.png');

  async function loadJSON(url){ return fetch(url).then(r=>r.json()); }
  const incidents = await loadJSON('assets/data/incidents.geojson').catch(()=>({features:[]}));

  Globe.pointsData(incidents.features)
       .pointLat(d => d.properties.lat)
       .pointLng(d => d.properties.lng)
       .pointAltitude(d => 0.01 + (d.properties.severity||1) * 0.02)
       .pointColor(d => d.properties.severity>2 ? 'red' : 'yellow')
       .pointsTransitionDuration(1500);

  scene.add(Globe);

  let rotate = true;
  function animate(){
    if(rotate) Globe.rotateY(0.002);
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  animate();

  window.GlobeApp = { globe: Globe, scene, camera, renderer, toggleRotate: ()=>{ rotate = !rotate } };
})();
