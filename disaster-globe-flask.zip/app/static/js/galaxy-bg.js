// Create a full-screen canvas behind the WebGL canvas to render starfield
(function(){
  const c = document.createElement('canvas');
  c.id = 'starfield';
  c.style.position = 'fixed';
  c.style.left = '0';
  c.style.top = '0';
  c.style.zIndex = '0';
  c.style.pointerEvents = 'none';
  document.body.appendChild(c);

  const ctx = c.getContext('2d');
  function resize(){ c.width = innerWidth; c.height = innerHeight; draw(); }
  addEventListener('resize', resize);

  let stars = [];
  function generate(){
    stars = [];
    const count = Math.max(300, Math.round((innerWidth*innerHeight)/5000));
    for(let i=0;i<count;i++){
      stars.push({
        x: Math.random()*innerWidth,
        y: Math.random()*innerHeight,
        r: Math.random()*1.6,
        a: Math.random()*0.9+0.1
      });
    }
  }
  function draw(){
    ctx.clearRect(0,0,c.width,c.height);
    const g = ctx.createRadialGradient(c.width*0.7, c.height*0.2, 10, c.width*0.5, c.height*0.5, Math.max(c.width,c.height));
    g.addColorStop(0,'rgba(30,10,40,0.25)');
    g.addColorStop(0.5,'rgba(10,10,30,0.2)');
    g.addColorStop(1,'rgba(0,0,5,0.7)');
    ctx.fillStyle = g;
    ctx.fillRect(0,0,c.width,c.height);

    for(const s of stars){
      ctx.beginPath();
      ctx.globalAlpha = s.a;
      ctx.fillStyle = 'white';
      ctx.arc(s.x,s.y,s.r,0,Math.PI*2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function animate(){
    for(const s of stars){
      s.a += (Math.random()-0.5)*0.02;
      s.a = Math.max(0.05,Math.min(1,s.a));
    }
    draw();
    requestAnimationFrame(animate);
  }

  resize();
  generate();
  animate();
})();
