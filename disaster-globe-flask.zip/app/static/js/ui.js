document.getElementById('btn-rotate').addEventListener('click', () => {
  const app = window.GlobeApp;
  app && app.toggleRotate();
});
document.getElementById('btn-toggle-points').addEventListener('click', () => {
  const g = window.GlobeApp && window.GlobeApp.globe;
  if(!g) return;
  const visible = g.pointsData()? false : true;
  if(!visible) g.pointsData([]); else fetch('assets/data/incidents.geojson').then(r=>r.json()).then(j=>g.pointsData(j.features));
});
document.getElementById('btn-screenshot').addEventListener('click', () => {
  const renderer = window.GlobeApp.renderer;
  if(!renderer) return;
  const dataURL = renderer.domElement.toDataURL('image/png');
  const a = document.createElement('a'); a.href = dataURL; a.download = 'globe-snapshot.png'; a.click();
});
