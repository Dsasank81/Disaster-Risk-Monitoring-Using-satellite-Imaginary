from app import create_app

def test_incidents_endpoint_empty():
    app = create_app()
    client = app.test_client()
    resp = client.get("/api/incidents")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "features" in data
